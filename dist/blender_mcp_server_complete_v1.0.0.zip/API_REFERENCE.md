# Blender MCP Server API Reference

This document provides detailed information about all available commands, parameters, and responses for the Blender MCP Server.

## Table of Contents

- [Connection](#connection)
- [Message Format](#message-format)
- [Object Commands](#object-commands)
- [Scene Commands](#scene-commands)
- [Render Commands](#render-commands)
- [System Commands](#system-commands)
- [Error Handling](#error-handling)
- [Examples](#examples)

## Connection

### WebSocket Connection

**URL Format:** `ws://host:port`
- Default: `ws://localhost:8765`
- Protocol: WebSocket with JSON messages
- Authentication: IP-based access control

### Connection Process

1. Establish WebSocket connection
2. Server validates client IP against allowed list
3. Send commands as JSON messages
4. Receive responses as JSON messages
5. Close connection when done

## Message Format

### Request Format

All requests must be valid JSON objects with the following structure:

```json
{
    "command": "string",     // Required: Command name
    "params": {              // Required: Command parameters (can be empty object)
        "key": "value"
    }
}
```

### Response Format

All responses are JSON objects with the following structure:

```json
{
    "success": boolean,      // Required: true if command succeeded
    "data": object,          // Optional: Response data
    "message": "string",     // Optional: Human-readable message
    "error": "string"        // Optional: Error description (if success=false)
}
```

## Object Commands

### create_object

Creates a new 3D object in the scene.

**Parameters:**
- `type` (string, required): Object type
  - Valid values: `"cube"`, `"sphere"`, `"cylinder"`, `"plane"`, `"cone"`, `"torus"`
- `name` (string, required): Object name (must be unique)
- `location` (array, optional): 3D position [x, y, z]
  - Default: `[0, 0, 0]`
  - Range: ±1,000,000 per axis

**Example Request:**
```json
{
    "command": "create_object",
    "params": {
        "type": "cube",
        "name": "MyCube",
        "location": [1.0, 2.0, 3.0]
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Created cube 'MyCube' at [1.0, 2.0, 3.0]",
    "data": {
        "name": "MyCube",
        "type": "cube",
        "location": [1.0, 2.0, 3.0]
    }
}
```

### move_object

Moves an existing object to a new location.

**Parameters:**
- `name` (string, required): Object name
- `location` (array, required): New 3D position [x, y, z]

**Example Request:**
```json
{
    "command": "move_object",
    "params": {
        "name": "MyCube",
        "location": [5.0, 0.0, 2.0]
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Moved object 'MyCube' to [5.0, 0.0, 2.0]",
    "data": {
        "name": "MyCube",
        "location": [5.0, 0.0, 2.0]
    }
}
```

### rotate_object

Rotates an existing object.

**Parameters:**
- `name` (string, required): Object name
- `rotation` (array, required): Rotation in degrees [x, y, z]

**Example Request:**
```json
{
    "command": "rotate_object",
    "params": {
        "name": "MyCube",
        "rotation": [45.0, 0.0, 90.0]
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Rotated object 'MyCube' to [45.0, 0.0, 90.0] degrees",
    "data": {
        "name": "MyCube",
        "rotation_degrees": [45.0, 0.0, 90.0],
        "rotation_radians": [0.785, 0.0, 1.571]
    }
}
```

### scale_object

Scales an existing object.

**Parameters:**
- `name` (string, required): Object name
- `scale` (array, required): Scale factors [x, y, z]
  - Must be positive numbers

**Example Request:**
```json
{
    "command": "scale_object",
    "params": {
        "name": "MyCube",
        "scale": [2.0, 1.5, 1.0]
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Scaled object 'MyCube' to [2.0, 1.5, 1.0]",
    "data": {
        "name": "MyCube",
        "scale": [2.0, 1.5, 1.0]
    }
}
```

### set_material

Applies material properties to an object.

**Parameters:**
- `name` (string, required): Object name
- `material` (object, required): Material properties
  - `color` (array or string, optional): Color as [r, g, b, a] (0-1) or hex "#RRGGBB"
  - `metallic` (number, optional): Metallic value (0-1)
  - `roughness` (number, optional): Roughness value (0-1)

**Example Request:**
```json
{
    "command": "set_material",
    "params": {
        "name": "MyCube",
        "material": {
            "color": [0.8, 0.2, 0.2, 1.0],
            "metallic": 0.5,
            "roughness": 0.3
        }
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Applied material to object 'MyCube'",
    "data": {
        "name": "MyCube",
        "material_name": "MyCube_material",
        "properties": {
            "color": [0.8, 0.2, 0.2, 1.0],
            "metallic": 0.5,
            "roughness": 0.3
        }
    }
}
```

## Scene Commands

### get_scene_info

Retrieves information about the current scene.

**Parameters:** None (empty object)

**Example Request:**
```json
{
    "command": "get_scene_info",
    "params": {}
}
```

**Example Response:**
```json
{
    "success": true,
    "data": {
        "scene_name": "Scene",
        "objects": [
            {
                "name": "Camera",
                "type": "CAMERA",
                "location": [7.36, -6.93, 4.96],
                "rotation": [63.43, 0.0, 46.69],
                "scale": [1.0, 1.0, 1.0],
                "visible": true,
                "material": null
            },
            {
                "name": "MyCube",
                "type": "MESH",
                "location": [5.0, 0.0, 2.0],
                "rotation": [45.0, 0.0, 90.0],
                "scale": [2.0, 1.5, 1.0],
                "visible": true,
                "material": "MyCube_material"
            }
        ],
        "object_count": 2,
        "camera": {
            "name": "Camera",
            "location": [7.36, -6.93, 4.96],
            "rotation": [63.43, 0.0, 46.69]
        },
        "render_settings": {
            "resolution_x": 1920,
            "resolution_y": 1080,
            "engine": "BLENDER_EEVEE",
            "filepath": "/tmp/"
        },
        "active_object": "MyCube"
    }
}
```

### clear_scene

Removes all user-created objects from the scene, preserving default camera and light.

**Parameters:** None (empty object)

**Example Request:**
```json
{
    "command": "clear_scene",
    "params": {}
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Cleared scene: deleted 5 objects, preserved 2 default objects",
    "data": {
        "deleted_count": 5,
        "preserved_objects": ["Camera", "Light"],
        "deleted_objects": ["MyCube", "Sphere", "Cylinder", "Plane", "Cone"]
    }
}
```

## Render Commands

### render_scene

Renders the current scene to an image file.

**Parameters:**
- `output_path` (string, optional): Output file path
  - Default: `/tmp/blender_render_{timestamp}.png`
- `resolution` (array, optional): Image resolution [width, height]
- `engine` (string, optional): Render engine
  - Valid values: `"CYCLES"`, `"BLENDER_EEVEE"`, `"BLENDER_WORKBENCH"`

**Example Request:**
```json
{
    "command": "render_scene",
    "params": {
        "output_path": "/tmp/my_render.png",
        "resolution": [1920, 1080],
        "engine": "BLENDER_EEVEE"
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Scene rendered successfully in 2.34 seconds",
    "data": {
        "output_path": "/tmp/my_render.png",
        "render_time": 2.34,
        "file_size": 1048576,
        "resolution": [1920, 1080],
        "engine": "BLENDER_EEVEE"
    }
}
```

### set_render_settings

Configures render settings.

**Parameters:**
- `resolution` (array, optional): Image resolution [width, height]
- `engine` (string, optional): Render engine
- `samples` (integer, optional): Sample count (1-10000)
- `format` (string, optional): Output format
  - Valid values: `"PNG"`, `"JPEG"`, `"TIFF"`, `"OPEN_EXR"`, `"HDR"`
- `quality` (integer, optional): JPEG quality (0-100)

**Example Request:**
```json
{
    "command": "set_render_settings",
    "params": {
        "resolution": [1920, 1080],
        "engine": "CYCLES",
        "samples": 128,
        "format": "PNG"
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "Render settings updated",
    "data": {
        "settings_applied": {
            "resolution": [1920, 1080],
            "engine": "CYCLES",
            "samples": 128,
            "format": "PNG"
        },
        "current_settings": {
            "resolution": [1920, 1080],
            "engine": "CYCLES",
            "format": "PNG",
            "filepath": "/tmp/",
            "samples": 128,
            "device": "CPU"
        }
    }
}
```

### get_render_settings

Retrieves current render settings.

**Parameters:** None (empty object)

**Example Request:**
```json
{
    "command": "get_render_settings",
    "params": {}
}
```

**Example Response:**
```json
{
    "success": true,
    "data": {
        "resolution": [1920, 1080],
        "engine": "CYCLES",
        "format": "PNG",
        "filepath": "/tmp/",
        "samples": 128,
        "device": "CPU"
    }
}
```

## System Commands

### ping

Tests server connectivity and responsiveness.

**Parameters:**
- `echo` (string, optional): Message to echo back

**Example Request:**
```json
{
    "command": "ping",
    "params": {
        "echo": "Hello Server"
    }
}
```

**Example Response:**
```json
{
    "success": true,
    "message": "pong",
    "data": {
        "timestamp": 1640995200.123,
        "echo": "Hello Server"
    }
}
```

### get_server_status

Retrieves server status and statistics.

**Parameters:** None (empty object)

**Example Request:**
```json
{
    "command": "get_server_status",
    "params": {}
}
```

**Example Response:**
```json
{
    "success": true,
    "data": {
        "running": true,
        "server_config": {
            "host": "localhost",
            "port": 8765,
            "allowed_ips": ["127.0.0.1", "localhost"]
        },
        "client_stats": {
            "total_clients": 1,
            "clients": {
                "127.0.0.1:54321": {
                    "ip": "127.0.0.1",
                    "connected_duration": 120.5,
                    "last_activity": 2.1,
                    "message_count": 15
                }
            }
        },
        "uptime": 3600.0
    }
}
```

### get_error_stats

Retrieves error statistics.

**Parameters:** None (empty object)

**Example Request:**
```json
{
    "command": "get_error_stats",
    "params": {}
}
```

**Example Response:**
```json
{
    "success": true,
    "data": {
        "total_errors": 3,
        "error_counts": {
            "VALIDATION_create_object": 2,
            "BLENDER_API_move_object": 1
        },
        "categories": {
            "VALIDATION": 2,
            "BLENDER_API": 1,
            "CONNECTION": 0,
            "COMMAND": 0,
            "SYSTEM": 0,
            "TIMEOUT": 0,
            "SECURITY": 0
        }
    }
}
```

## Error Handling

### Error Response Format

When a command fails, the response includes error information:

```json
{
    "success": false,
    "error": "ERROR_CODE: Detailed error message",
    "data": {
        "error_code": "ERROR_CODE",
        "category": "ERROR_CATEGORY",
        "details": "Additional error details",
        "context": {
            "key": "value"
        }
    }
}
```

### Common Error Codes

- `UNKNOWN_COMMAND`: Command not recognized
- `INVALID_JSON`: Malformed JSON message
- `VALIDATION_ERROR`: Invalid parameters
- `OBJECT_NOT_FOUND`: Referenced object doesn't exist
- `BLENDER_ERROR`: Blender API operation failed
- `TIMEOUT`: Command execution timed out
- `CONNECTION_ERROR`: WebSocket connection issue

### Error Categories

- `CONNECTION`: WebSocket connection issues
- `VALIDATION`: Parameter validation failures
- `BLENDER_API`: Blender operation failures
- `COMMAND`: Command processing errors
- `SYSTEM`: System-level errors
- `TIMEOUT`: Operation timeouts
- `SECURITY`: Security violations

## Examples

### Complete Workflow Example

```python
import asyncio
import websockets
import json

async def create_scene():
    uri = "ws://localhost:8765"
    
    async with websockets.connect(uri) as websocket:
        # Test connection
        await websocket.send(json.dumps({
            "command": "ping",
            "params": {}
        }))
        response = json.loads(await websocket.recv())
        print(f"Ping: {response['message']}")
        
        # Clear scene
        await websocket.send(json.dumps({
            "command": "clear_scene",
            "params": {}
        }))
        response = json.loads(await websocket.recv())
        print(f"Clear: {response['message']}")
        
        # Create objects
        objects = [
            ("cube", "Table", [0, 0, 0.5]),
            ("cylinder", "Leg1", [-1, -1, 0]),
            ("cylinder", "Leg2", [1, -1, 0]),
            ("cylinder", "Leg3", [1, 1, 0]),
            ("cylinder", "Leg4", [-1, 1, 0])
        ]
        
        for obj_type, name, location in objects:
            await websocket.send(json.dumps({
                "command": "create_object",
                "params": {
                    "type": obj_type,
                    "name": name,
                    "location": location
                }
            }))
            response = json.loads(await websocket.recv())
            print(f"Created: {response['message']}")
        
        # Apply materials
        await websocket.send(json.dumps({
            "command": "set_material",
            "params": {
                "name": "Table",
                "material": {
                    "color": [0.6, 0.4, 0.2, 1.0],
                    "roughness": 0.8
                }
            }
        }))
        response = json.loads(await websocket.recv())
        print(f"Material: {response['message']}")
        
        # Render scene
        await websocket.send(json.dumps({
            "command": "render_scene",
            "params": {
                "output_path": "/tmp/table_scene.png",
                "resolution": [800, 600]
            }
        }))
        response = json.loads(await websocket.recv())
        print(f"Render: {response['message']}")

# Run the example
asyncio.run(create_scene())
```

This completes the API reference documentation with detailed information about all available commands, parameters, responses, and error handling.