# Blender MCP Server Installation Guide

## Prerequisites

- Blender 3.0 or later
- Python websockets library (usually included with Blender)

## Installation Steps

### Method 1: Manual Installation

1. **Download the addon**
   - Copy the entire `blender_mcp_server` folder to your Blender addons directory:
     - Windows: `%APPDATA%\Blender Foundation\Blender\[version]\scripts\addons\`
     - macOS: `~/Library/Application Support/Blender/[version]/scripts/addons/`
     - Linux: `~/.config/blender/[version]/scripts/addons/`

2. **Enable the addon**
   - Open Blender
   - Go to Edit > Preferences > Add-ons
   - Search for "Blender MCP Server"
   - Check the box to enable the addon

3. **Configure the server**
   - In the addon preferences, configure:
     - Host: `localhost` (for local connections) or `0.0.0.0` (for remote connections)
     - Port: `8765` (default) or any available port
     - Allowed IPs: `127.0.0.1,localhost` (for local only) or `0.0.0.0` (for any IP)
     - Auto-start: Enable to start server automatically when Blender starts

### Method 2: Install from ZIP

1. **Create addon ZIP**
   - Zip the `blender_mcp_server` folder
   - Name it `blender_mcp_server.zip`

2. **Install in Blender**
   - Open Blender
   - Go to Edit > Preferences > Add-ons
   - Click "Install..." button
   - Select the ZIP file
   - Enable the addon

## Usage

### Starting the Server

The server can be started in several ways:

1. **Automatic start** (if enabled in preferences)
   - Server starts when addon is enabled
   - Server starts when Blender starts (if addon is enabled)

2. **Manual start from preferences**
   - Go to Edit > Preferences > Add-ons
   - Find "Blender MCP Server"
   - Click "Start Server" button

3. **Manual start from 3D viewport**
   - In 3D viewport, open the sidebar (N key)
   - Go to "MCP Server" tab
   - Click "Start Server"

### Server Status

Check server status in:
- Addon preferences panel
- 3D viewport sidebar "MCP Server" tab
- Blender console (Window > Toggle System Console)

### Testing the Connection

1. **Built-in test**
   - Use the "Test Connection" button in addon preferences

2. **External test**
   - Run the provided `test_mcp_compatibility.py` script
   - Use any WebSocket client to connect to `ws://localhost:8765`

3. **Test with your application**
   - Use the existing `BlenderMCPClient` from your project
   - Connect to the configured host and port

## Configuration Options

### Network Settings

- **Host**: Server bind address
  - `localhost` or `127.0.0.1`: Local connections only
  - `0.0.0.0`: Accept connections from any IP
  - Specific IP: Accept connections from that IP only

- **Port**: Server port number
  - Default: `8765`
  - Must be available (not used by other applications)
  - Range: 1024-65535 recommended

- **Allowed IPs**: Comma-separated list of allowed client IPs
  - `127.0.0.1,localhost`: Local connections only
  - `0.0.0.0`: Any IP allowed
  - `192.168.1.100,10.0.0.50`: Specific IPs only

### Advanced Settings

- **Auto-start**: Start server when addon is enabled
- **Log Level**: Logging verbosity (DEBUG, INFO, WARNING, ERROR)

## Troubleshooting

### Server Won't Start

1. **Port already in use**
   - Change port number in preferences
   - Check if another application is using the port

2. **Permission denied**
   - Try a different port (above 1024)
   - Run Blender as administrator (not recommended)

3. **Network interface issues**
   - Try `127.0.0.1` instead of `localhost`
   - Check firewall settings

### Connection Issues

1. **Client can't connect**
   - Verify server is running (check status in preferences)
   - Check host and port settings
   - Verify client is using correct address

2. **Connection rejected**
   - Check "Allowed IPs" setting
   - Add client IP to allowed list
   - Use `0.0.0.0` in allowed IPs for testing

3. **Commands not working**
   - Check Blender console for error messages
   - Verify command format matches expected JSON structure
   - Test with simple commands like `ping` first

### Performance Issues

1. **Slow responses**
   - Check Blender console for errors
   - Reduce scene complexity
   - Lower render settings for testing

2. **Memory issues**
   - Restart Blender periodically
   - Clear scene between tests
   - Monitor system resources

## Security Considerations

- **Local development**: Use `localhost` and `127.0.0.1` in allowed IPs
- **Network access**: Be careful with `0.0.0.0` - it allows any IP to connect
- **Firewall**: Configure firewall to block the port if not needed externally
- **Production**: Use specific IP addresses in allowed IPs list

## Support

For issues and questions:
1. Check Blender console for error messages
2. Review this installation guide
3. Test with the provided compatibility script
4. Check addon preferences for configuration issues

## Available Commands

The server supports all commands expected by `BlenderMCPClient`:

### Object Commands
- `create_object` - Create new objects
- `move_object` - Move objects
- `rotate_object` - Rotate objects  
- `scale_object` - Scale objects
- `set_material` - Set object materials

### Scene Commands
- `get_scene_info` - Get scene information
- `clear_scene` - Clear scene objects

### Render Commands
- `render_scene` - Render scene to image
- `set_render_settings` - Configure render settings
- `get_render_settings` - Get current render settings

### System Commands
- `ping` - Test connection
- `get_server_status` - Get server status
- `get_error_stats` - Get error statistics